package com.example.assignments

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
